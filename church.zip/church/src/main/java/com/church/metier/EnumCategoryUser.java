package com.church.metier;

public enum EnumCategoryUser {
	ADMIN,
	MUSICIAN,
	ADHERENT;
}
