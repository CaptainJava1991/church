package com.church.metier;

import javax.persistence.*;
import javax.validation.constraints.*;

import com.church.validator.ValidEmail;
import com.church.validator.ValidName;

@Entity
@Table(name = "USER")
public class User {
	@Id @GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name = "USERID")
	private int userId;
	
	@NotNull @ValidName
	@Size(min=1, message = "min 1 Letter")
	@Column(name="NAME")
	private String name;
	
	@NotNull @ValidName
	@Size(min=1, message = "min 1 Letter")
	@Column(name="FIRSTNAME")
	private String firstName;
	
	@NotNull @ValidEmail
	@Column(unique = true, name="MAIL")
	private String mail;
	
	@NotNull
	@Column(name="PASSWORD")
	@Size(min = 4, message = "min 4 Letter")
	private String password;
	
/*	@NotNull
	@ValidEqual(value = )
	@Size(min = 4, message = "min 4 Letter")
	private String passwordConfirm;*/
	
	@Column(name="PHONE")
	private String phone;
	
	@NotNull
	@Column(name="CATEGORYUSER")
	private EnumCategoryUser categoryUser = EnumCategoryUser.ADHERENT;
	
	public void setUserId(int userId){
		this.userId = userId;
	}
	
	public int getIdUser() {
		return userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public EnumCategoryUser getCategoryUser() {
		return categoryUser;
	}
	public void setCategoryUser(EnumCategoryUser categoryUser) {
		this.categoryUser = categoryUser;
	}
	
	
}
