package com.church.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import bean.form.LoginFormBean;


@Controller
@RequestMapping("/login")
public class LoginController {

	@RequestMapping(value = "", method = RequestMethod.GET)
	public String loginGet(ModelMap model, HttpServletRequest request, HttpServletRequest response) {
		model.addAttribute("loginFormBean", new LoginFormBean());
		return "login";
	}
	
	@RequestMapping(value = "", method = RequestMethod.POST)
	public String loginPost(@Valid LoginFormBean loginFormBean, BindingResult result, Model m) {
		if(result.hasErrors()) {
			return "login";
		}
		
		return "index";
		
	}
}
