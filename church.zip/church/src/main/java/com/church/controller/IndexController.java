package com.church.controller;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.church.metier.User;
import com.church.util.HibernateUtil;



@Controller
@RequestMapping("/")
public class IndexController {
	
	@RequestMapping(value = "", method = RequestMethod.GET)
	public String indexGet(ModelMap model, HttpServletRequest request, HttpServletRequest response) {

             
            Session session= HibernateUtil.getCurrentSession();
            org.hibernate.Transaction trans=session.beginTransaction();
            

    	
		User admin = new User();
		admin.setUserId(1);
		admin.setName("admin");
		admin.setFirstName("admin");
		admin.setMail("admin@admin.admin");
		admin.setPassword("admin");
		session.saveOrUpdate(admin);
		trans.commit();
		session.close();
		HibernateUtil.closeFactorySession();
		return "index";
	}


}
