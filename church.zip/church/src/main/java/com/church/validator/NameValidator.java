package com.church.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class NameValidator implements ConstraintValidator<ValidName, String>{
	  
	  public void initialize(ValidName constraintAnnotation) { }
	  
	  private boolean validateEmail(String name) {
		  for(int i = 0; i < name.length(); i++){
			  if(Character.isLetter(name.charAt(i)) 
					  || name.charAt(i) == '-'
				  	   || name.charAt(i) == ' '){
				  		   
			   }else{
				   return false;
			   }
		  }
		  return true;
	  }
	  


	public boolean isValid(String mail, ConstraintValidatorContext context) {
		
		return (validateEmail(mail));
	}
}