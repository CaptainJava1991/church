package com.church.util;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
    private static SessionFactory sf;  
    
    
    public static Session getCurrentSession() throws HibernateException {
    	if(sf == null){
    		SessionFactory sf = new Configuration().configure().buildSessionFactory();
    		return sf.openSession();
    	}
    	return sf.openSession();
    }
    
    
    public static void closeFactorySession(){
    	sf.close();
    }
}
