package bean.form;

import javax.validation.constraints.Size;

import com.church.validator.ValidEmail;

public class LoginFormBean {
	@ValidEmail
	private String mail = "";
	@Size(min=4, message="min 4 Letter")
	private String password = "";
	
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
